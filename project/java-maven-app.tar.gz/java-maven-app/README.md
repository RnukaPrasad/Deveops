# java-maven-app



The repository contains a simple Java application which outputs the string
"Hello world!"


to build

mvn clean install


to run the application

scripts/deliver.sh

