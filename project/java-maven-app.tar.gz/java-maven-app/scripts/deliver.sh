#!/usr/bin/env bash

java -jar target/my-app-1.0-SNAPSHOT.jar
